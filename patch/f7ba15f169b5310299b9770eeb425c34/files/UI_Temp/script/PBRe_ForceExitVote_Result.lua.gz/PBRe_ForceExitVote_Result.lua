require "Script.uiLuaString.pbString"
require "Script.uiLua.uiUtil"


Use("i3UIStaticText_Subject")
Use("i3UIStaticText_Content")



g_Update = false
g_UpdateTime = 0.0


class "result" (eventHandler)

function result:__init()

end

function result:OnEvent(evt,...)
end

function result:OnUpdate(tm)
	if g_Update == true then
		g_UpdateTime = g_UpdateTime + tm
		
		if g_UpdateTime > 5 then
			g_UpdateTime = 0.0
			g_Update = false
			Close_ForceExit_Result()
		end
	end
end


function result:SetMsg( title, msg )
	i3UIStaticText_Subject:setText(title)
	i3UIStaticText_Content:setText(msg)
	g_Update = true
	g_UpdateTime = 0.0
end


PBRe_ForceExitVote_Result = result()


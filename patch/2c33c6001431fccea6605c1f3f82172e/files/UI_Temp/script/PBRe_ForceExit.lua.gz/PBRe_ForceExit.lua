require "Script.uiLuaString.pbString"
require "Script.uiLua.uiUtil"


Use("i3UIStaticText_Subject")  -- subject
Use("i3UIStaticText_Nick") -- text nick
Use("i3UIStaticText_Reason") -- text reason

Use("i3UIComboBox")		--  reason combo
Use("i3UIListView_Box") -- user list

Use("i3UIFrameWnd")
Use("i3UIButtonComposed_OK") -- OK
Use("i3UIButtonComposed_Cancel")


i3UIComboBox:enableUIEvent(UI_EVT_SELITEM)

function i3UIComboBox:OnSelItem(...)
	local sel, from = ...
	SelectReason(sel)
end

i3UIComboBox:enableUIEvent(UI_EVT_COMBOBOX_UNFOLDED)

function i3UIComboBox:OnComboBoxUnfolded()

	i3UIListView_Box:setInputDisable(true)
	
end

i3UIComboBox:enableUIEvent(UI_EVT_COMBOBOX_FOLDED)

function i3UIComboBox:OnComboBoxFolded()

	i3UIListView_Box:setInputDisable(false)

end


gSlotCount = 0

function i3UIListView_Box:AddSlot( count)
	for i=1,count,1 do
		self:AddData( "", "", "")
		self:EmptySlot( gSlotCount)
		gSlotCount = gSlotCount + 1
	end

	self:UpdateToPreviewMode()
end

function i3UIListView_Box:DeleteSlot( slot)
	self:DeleteData( slot)			
	gSlotCount = gSlotCount -1
end

function i3UIListView_Box:EmptySlot( slot)
	local control = uiLV_GetCellControl( self.ctrlID, slot, 0)
	uiCtrl_setEnable( control, false)

	self:SetCell( slot, 1, "")
	self:SetCell( slot, 2, "")
end

function i3UIListView_Box:SetSlotCount( count)
	local precount = self:GetDataCount()
	local addCount = count - precount

	if addCount > 0 then
		self:AddSlot( addCount)
	elseif addCount < 0 then
		for i = precount-1,count,-1 do
			if gSlotCount > 6 then
				self:DeleteSlot(i)
			else
				self:EmptySlot(i)
			end
		end
		self:UpdateToPreviewMode()
	end
end

function i3UIListView_Box:SetSlotInfo( slot, nick)
	local control = uiLV_GetCellControl( self.ctrlID, slot, 0)
	uiCtrl_setEnable( control, true)

	self:SetCell( slot, 2, nick)
end

function i3UIListView_Box:InitListBox()
	self:SetTextAlign( "Left", "Middle", "Column", 2, 0)

	self:AddSlot(6)
end



i3UIListView_Box:enableUIEvent(UI_EVT_SELITEM)

function i3UIListView_Box:OnSelItem(...)
	local idx, from = ...
	SelectUser(idx)
end

i3UIListView_Box:enableUIEvent(UI_EVT_CLICKED)

function i3UIListView_Box:OnClicked(...)
		local idx, from = ...
	SelectUser(idx)
end


--[BLOCK_END:i3UIListView_Box]
---------------------------------------
--[BLOCK_START:i3UIButtonComposed3]


i3UIButtonComposed_OK:enableUIEvent(UI_EVT_CLICKED)

function i3UIButtonComposed_OK:OnClicked()
	OK()
end

--[BLOCK_END:i3UIButtonComposed3]
---------------------------------------
--[BLOCK_START:i3UIButtonComposed31]



i3UIButtonComposed_Cancel:enableUIEvent(UI_EVT_CLICKED)

function i3UIButtonComposed_Cancel:OnClicked()
	Close()
end

--[BLOCK_END:i3UIButtonComposed31]

---------------------------------------
--[BLOCK_START:UIRe\Script\PointBlankRe_ForceExit.lua]

class "forceremove" (eventHandler)

function forceremove:__init()
	i3UIStaticText_Subject:setText(STR_EXIT_POPUP_FORCIBLYREMOVE)
	i3UIStaticText_Reason:setText(STR_POPUP_FORCIBLYREMOVE_REASON)
	i3UIStaticText_Nick:setText(STR_POPUP_FORCIBLYREMOVE_USERNICK)
	i3UIButtonComposed_OK:setText(STR_POPUP_OK)
	i3UIButtonComposed_Cancel:setText(STR_POPUP_CANCEL)
	
	i3UIListView_Box:setInputDisable(false)

	i3UIListView_Box:InitListBox()
end

function forceremove:OnEvent(evt,...)
end

function forceremove:OnUpdate(tm)
end

function forceremove:SetComboList(str)
	i3UIComboBox:SetEditBoxReadOnly(true)
	i3UIComboBox:SetItems(str)
	i3UIComboBox:SetCurSel(0)
end

function forceremove:SetSlotCount(count)
	i3UIListView_Box:SetSlotCount(count)
	i3UIListView_Box:UnsetCurSel()
end

function forceremove:SetSlotInfo(slot, nick)
	i3UIListView_Box:SetSlotInfo( slot, nick)
end

PBRe_ForceExit = forceremove()

--[BLOCK_END:UIRe\Script\PointBlankRe_ForceExit.lua]




i3UIFrameWnd:enableUIEvent(UI_EVT_DISABLE)

function i3UIFrameWnd:OnDisable()
	i3UIComboBox:FoldListBox()
end

i3UIFrameWnd:enableUIEvent(UI_EVT_ENABLE)

function i3UIFrameWnd:OnEnable()
	
end

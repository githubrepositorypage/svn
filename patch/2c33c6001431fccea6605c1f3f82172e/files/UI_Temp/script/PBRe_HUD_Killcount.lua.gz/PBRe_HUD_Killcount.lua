require "Script.uiLua.uiUtil"

--[BLOCK_START:UIRe\Script\PBRe_HUD_Killcount.lua]

class "hudkillcount" (eventHandler)

function hudkillcount:__init()
end

function hudkillcount:OnEvent(evt,...)
end

function hudkillcount:OnUpdate(tm)
end

PBRe_HUD_Killcount = hudkillcount()

--[BLOCK_END:UIRe\Script\PBRe_HUD_Killcount.lua]
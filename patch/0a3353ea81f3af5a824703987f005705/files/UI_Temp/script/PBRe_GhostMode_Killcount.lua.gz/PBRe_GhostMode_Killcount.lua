require "Script.uiLua.uiUtil"

--[BLOCK_START:UIRe\Script\PBRe_GhostMode_Killcount.lua]

class "ghostkillcount" (eventHandler)

function ghostkillcount:__init()
end

function ghostkillcount:OnEvent(evt,...)
end

function ghostkillcount:OnUpdate(tm)
end

PBRe_GhostMode_Killcount = ghostkillcount()

--[BLOCK_END:UIRe\Script\PBRe_GhostMode_Killcount.lua]
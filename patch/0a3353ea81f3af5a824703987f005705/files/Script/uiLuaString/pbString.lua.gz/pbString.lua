require "Script.uiLuaString.Turkey.String_Turkey"



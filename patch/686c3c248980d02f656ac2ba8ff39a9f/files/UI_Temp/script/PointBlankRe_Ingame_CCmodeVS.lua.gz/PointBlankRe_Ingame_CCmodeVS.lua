require "Script.uiLua.uiUtil"


class "CCModeVS" (eventHandler)

function CCModeVS:__init()
end

function CCModeVS:OnEvent(evt,...)
end

function CCModeVS:OnUpdate(tm)
end

PointBlankRe_Ingame_CCmodeVS = CCModeVS()
---------------------------------------
--[BLOCK_START:UIRe\Script\CCMode\PointBlankRe_Ingame_CCmodeVS.lua]

--[BLOCK_END:UIRe\Script\CCMode\PointBlankRe_Ingame_CCmodeVS.lua]

require "Script.uiLua.uiUtil"


--[BLOCK_START:UIRe\Script\PointBlankRe_Ingame_select_char.lua]

Use("i3UIFrameWnd_Slot")
	Use("i3UIButtonImageSet2") 	--image Prev
	Use("i3UIButtonImageSet3")	--image Current
	Use("i3UIButtonImageSet4")	--image Next

	Use("i3UIStaticText13")		--empty Prev
	Use("i3UIStaticText14")		--empty Current
	Use("i3UIStaticText15")		--empty Next

	Use("i3UIStaticText16")		--name Prev
	Use("i3UIStaticText17")		--name Current
	Use("i3UIStaticText18")		--name Next


Use("i3UIFrameWnd_Repair_Prev")
	Use("Prev_NonZero")
		Use("i3UIProgressBar1_1")
		Use("i3UIProgressBar1_2")
		Use("i3UIProgressBar1_3")
		Use("i3UIProgressBar1_4")
	Use("Prev_Zero")
	--Use("Frame1_Event")


Use("i3UIFrameWnd_Repair_Current")
	Use("Current_NonZero")
		Use("i3UIProgressBar")
		Use("i3UIProgressBar0")
		Use("i3UIProgressBar1")
		Use("i3UIProgressBar2")
	Use("Current_Zero")


Use("i3UIFrameWnd_Repair_Next")
	Use("Next_NonZero")
		Use("i3UIProgressBar3")
		Use("i3UIProgressBar4")
		Use("i3UIProgressBar5")
		Use("i3UIProgressBar6")
	Use("Next_Zero")


Use("i3UIFrameWnd_Desc")
	Use("i3UIStaticText5")				--Desc name
	Use("i3UIStaticText6")				--Description


Use("i3UIFrameWnd_Skill")
	Use("i3UIStaticText_SkillTitle")	--title
	Use("i3UIButtonImageSet_Skill1")	--Skill1
	Use("i3UIButtonImageSet_Skill2")	--Skill2
	Use("i3UIStaticText_Skill1Desc")		--S1 Desc
	Use("i3UIStaticText_Skill2Desc")		--S2 Desc



Use("i3UIStaticText10")	--Use Desc
Use("i3UIStaticText11")	--Ok
Use("i3UIStaticText12")	--Cancel

Use("i3UIStaticText_Title") --Title
Use("i3UIButton_Ok")		--Button Ok
Use("i3UIButton_Cancel")	--Button Cancel

Use("i3UIButton_Prev")		--Slot Move Prev
Use("i3UIButton_Next")		--Slot Move Next


SlotControl = {
	empty 	= 1,
	name 	= 2,
	image 	= 3,
	repair 	= 4,
};

SKillControl = {
	image 	= 1,
	desc	= 2,
}

RepairControl = {
	repair_frame  	= 1,
	non_zero_frame 	= 2,
	bar1			= 3,
	bar2			= 4,
	bar3 			= 5,
	bar4			= 6,
	zero_frame		= 7,
}


--Repair Controls
Repair_Prev		= { i3UIFrameWnd_Repair_Prev, 	 Prev_NonZero, 	  i3UIProgressBar1_1, i3UIProgressBar1_2, i3UIProgressBar1_3, i3UIProgressBar1_4, Prev_Zero};
Repair_Current	= { i3UIFrameWnd_Repair_Current, Current_NonZero, i3UIProgressBar, 	  i3UIProgressBar0,   i3UIProgressBar1,   i3UIProgressBar2,   Current_Zero};
Repair_Next		= { i3UIFrameWnd_Repair_Next, 	 Next_NonZero, 	  i3UIProgressBar3,   i3UIProgressBar4,   i3UIProgressBar5,   i3UIProgressBar6,   Next_Zero};

--Slot Controls 	/empty/				/name/				/image/
Slot_Prev 		= { i3UIStaticText13, i3UIStaticText16, i3UIButtonImageSet2, Repair_Prev};
Slot_Current 	= { i3UIStaticText14, i3UIStaticText17, i3UIButtonImageSet3, Repair_Current};
Slot_Next 		= { i3UIStaticText15, i3UIStaticText18, i3UIButtonImageSet4, Repair_Next};

--Skill Controls
Skill1			= { i3UIButtonImageSet_Skill1, i3UIStaticText_Skill1Desc};
Skill2			= { i3UIButtonImageSet_Skill2, i3UIStaticText_Skill2Desc};


Slots = { Slot_Prev, Slot_Current, Slot_Next};
Skills = { Skill1, Skill2};

------------------------------------------------------------------------------------------
--Click Event
i3UIButton_Prev:enableUIEvent(UI_EVT_CLICKED);
i3UIButton_Next:enableUIEvent(UI_EVT_CLICKED);

i3UIButton_Ok:enableUIEvent(UI_EVT_CLICKED);
i3UIButton_Cancel:enableUIEvent(UI_EVT_CLICKED);

i3UIButtonImageSet2:enableUIEvent(UI_EVT_CLICKED);	-- Prev
i3UIButtonImageSet4:enableUIEvent(UI_EVT_CLICKED);	-- Next

function i3UIButton_Prev:OnClicked()
	ClickPrev();
end

function i3UIButton_Next:OnClicked()
	ClickNext();
end

function i3UIButton_Ok:OnClicked()
	--uiResetFocus();
	ClickOk();
end

function i3UIButton_Cancel:OnClicked()
	--uiResetFocus();
	ClickCancel();
end

function i3UIButtonImageSet2:OnClicked()
	ClickPrev();
end

function i3UIButtonImageSet4:OnClicked()
	ClickNext();
end

------------------------------------------------------------------------------------------


class "PointBlankRe_Ingame_select_char" (eventHandler)

function PointBlankRe_Ingame_select_char:OnEvent(evt, ...)
end


function PointBlankRe_Ingame_select_char:__init()
	i3UIStaticText10:setTextMB(GAME_STRING("STR_TBL_BATTLEGUI_NOTICE_SELECETWEAPON"));
	i3UIStaticText11:setTextMB(GAME_STRING("STBL_IDX_BUTTON_OK"));
	i3UIStaticText12:setTextMB(GAME_STRING("STBL_IDX_BUTTON_CLOSE"));

	i3UIStaticText13:setTextMB("Empty");
	i3UIStaticText14:setTextMB("Empty");
	i3UIStaticText15:setTextMB("Empty");

	i3UIStaticText_Title:setTextMB(GAME_STRING("STR_INVEN_CHRACTER"));

	i3UIStaticText_SkillTitle:setTextMB(GAME_STRING("STR_TBL_INGAME_HUD_CCROUND_SKILL"));
end


function PointBlankRe_Ingame_select_char:OnUpdate(tm)
end

function PointBlankRe_Ingame_select_char:SetEndurance( SlotIdx, Ratio)
	Slots[SlotIdx+1][SlotControl.repair][RepairControl.bar1]:setEnable(false);
	Slots[SlotIdx+1][SlotControl.repair][RepairControl.bar2]:setEnable(false);
	Slots[SlotIdx+1][SlotControl.repair][RepairControl.bar3]:setEnable(false);
	Slots[SlotIdx+1][SlotControl.repair][RepairControl.bar4]:setEnable(false);

	local bar_type = RepairControl.bar4;
	if( Ratio > 0.9) then
		bar_type = RepairControl.bar1;

	elseif( Ratio > 0.5) then
		bar_type = RepairControl.bar2;

	elseif( Ratio > 0.1) then
		bar_type = RepairControl.bar3;

	else
		bar_type = RepairControl.bar4;

	end

	Slots[SlotIdx+1][SlotControl.repair][bar_type]:setEnable(true);
	Slots[SlotIdx+1][SlotControl.repair][bar_type]:SetValue( Ratio);
end

function PointBlankRe_Ingame_select_char:UpdateSlot( SlotIdx, UseShapeName, Shape, Name, RepairItem, RepairRatio)
	Slots[SlotIdx+1][SlotControl.empty]:setEnable(false);
	Slots[SlotIdx+1][SlotControl.name]:setEnable(true);
	Slots[SlotIdx+1][SlotControl.image]:setEnable(true);

	-- ��UI�� setShapeByString�� ���.
	if( UseShapeName) then
		Slots[SlotIdx+1][SlotControl.image]:setShapeByString(Shape);
	else
		Slots[SlotIdx+1][SlotControl.image]:setShape(Shape);
	end

	Slots[SlotIdx+1][SlotControl.name]:setText(Name);
	Slots[SlotIdx+1][SlotControl.repair][RepairControl.repair_frame]:setEnable(RepairItem);

	if( RepairItem == true) then
		if( RepairRatio < 0.01) then
			Slots[SlotIdx+1][SlotControl.repair][RepairControl.zero_frame]:setEnable(true);
			Slots[SlotIdx+1][SlotControl.repair][RepairControl.non_zero_frame]:setEnable(false);

		else
			Slots[SlotIdx+1][SlotControl.repair][RepairControl.zero_frame]:setEnable(false);
			Slots[SlotIdx+1][SlotControl.repair][RepairControl.non_zero_frame]:setEnable(true);

			self:SetEndurance( SlotIdx, RepairRatio);
		end

	end

end

function PointBlankRe_Ingame_select_char:EmptySlot( SlotIdx)
	Slots[SlotIdx+1][SlotControl.empty]:setEnable(true);

	Slots[SlotIdx+1][SlotControl.name]:setEnable(false);
	Slots[SlotIdx+1][SlotControl.image]:setEnable(false);
	Slots[SlotIdx+1][SlotControl.repair][RepairControl.repair_frame]:setEnable(false);
end

function PointBlankRe_Ingame_select_char:UpdateDesc( Name, Desc)
	i3UIStaticText5:setText(Name);
	i3UIStaticText6:setText(Desc);
end

function PointBlankRe_Ingame_select_char:UpdateSkill( SkillIdx, ShapeIdx, Desc)
	Skills[SkillIdx+1][SKillControl.image]:setShape(ShapeIdx);
	Skills[SkillIdx+1][SKillControl.desc]:setText(Desc);
end

PointBlankRe_Ingame_select_char = PointBlankRe_Ingame_select_char()

---------------------------------------
--[BLOCK_END:UIRe\Script\PointBlankRe_Ingame_select_char.lua]

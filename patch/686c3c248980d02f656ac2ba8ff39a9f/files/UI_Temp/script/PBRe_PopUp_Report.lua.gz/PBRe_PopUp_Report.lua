require "Script.uiLuaString.pbString"
require "Script.uiLua.uiUtil"

g_RadioCtrlList = {}
g_nReportSelectedUser = -1

Use( "radioBtn_HackTool" )
Use( "radioBtn_BadLanguage" )
Use( "btn_OK" )
Use( "btn_Cancel" )

btn_OK:enableUIEvent(UI_EVT_CLICKED)
btn_Cancel:enableUIEvent(UI_EVT_CLICKED)

function btn_OK:OnClicked()
	IngameReport()
end

function btn_Cancel:OnClicked()
	Close()
end

for n = 1, 15 do
	local radioName = "i3UIRadio" .. n 		
	Use( radioName )
	
	local radioCtrl = _G[ radioName ]
	table.insert( g_RadioCtrlList, radioCtrl )
	
	radioCtrl.m_nReportUserIdx = n
	radioCtrl:enableUIEvent( UI_EVT_BTN_PUSHED )
	
	radioCtrl.OnBtnPushed = function( self, ... )
		g_nReportSelectedUser = self.m_nReportUserIdx
	end
end

class "report" (eventHandler)

function 	report:__init()
	radioBtn_HackTool:setText( STR_TBL_REPORT_USE_HACK )
	radioBtn_BadLanguage:setText( STR_TBL_REPORT_BAD_LANGUAGE  )
	btn_OK:setText( STR_TBL_REPORT )
	btn_Cancel:setText( STR_POPUP_CANCEL )
end

function 	report:OnEvent(evt,...)
end

function 	report:OnUpdate(tm)
end

function 	report:SetUserList( ... )
	radioBtn_HackTool:setCheck( true )
	radioBtn_BadLanguage:setCheck( false )

	g_nReportSelectedUser = 1

	local data = ...
	local userList = data and { ... } or {}
	
	for n, nickName in ipairs( userList ) do
		g_RadioCtrlList[ n ]:setEnable( true )
		g_RadioCtrlList[ n ]:setText( nickName )
		g_RadioCtrlList[ n ]:setCheck( false )
	end
	
	for n = #userList +1, 15 do		
		g_RadioCtrlList[ n ]:setEnable( false )
		g_RadioCtrlList[ n ]:setCheck( false )
	end
	
	if 1 <= #userList then
		g_nReportSelectedUser = 1
		g_RadioCtrlList[ 1 ]:setCheck( true )
	else
		g_nReportSelectedUser = -1
	end
end

function	report:GetSelectedReportType()
	
	if radioBtn_HackTool:isChecked() then
		return 0
	end
	
	if radioBtn_BadLanguage:isChecked() then
		return 1
	end

	return -1	
end

function	report:GetSelectedUser()
	return g_nReportSelectedUser -1
end

PBRe_PopUp_Report = report()
---------------------------------------
--[BLOCK_START:UIRe\Script\PBRe_PopUp_Report.lua]

--[BLOCK_END:UIRe\Script\PBRe_PopUp_Report.lua]
---------------------------------------
--[BLOCK_START:UI_Temp\script\PBRe_PopUp_Report.lua]

--[BLOCK_END:UI_Temp\script\PBRe_PopUp_Report.lua]

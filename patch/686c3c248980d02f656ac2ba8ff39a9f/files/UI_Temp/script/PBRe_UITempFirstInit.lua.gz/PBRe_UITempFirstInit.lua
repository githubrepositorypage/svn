--require ���� ����
require "Script.uiLua.uiUtil"

class "first_init" (eventHandler)

function first_init:__init()
end

function first_init:OnEvent(evt,...)
end

function first_init:OnUpdate(tm)
end

PBRe_UITempFirstInit = first_init()
--[BLOCK_END:UITemp\Script\PBRe_UITempFirstInit.lua]

--require ���� ����
require "Script.uiLua.uiUtil"

Use("i3UIStaticText")
-- Title Label
Use("i3UIStaticText_Title")

-- Item1 Control
Use("i3UIFrameWnd_Item1")
Use("i3UIStaticText_Item1")
Use("i3UIImageBox_Item1")
Use("i3UIButtonImageSet_Item1")

-- Item2 Control
Use("i3UIFrameWnd_Item2")
Use("i3UIStaticText_Item2")
Use("i3UIImageBox_Item2")
Use("i3UIButtonImageSet_Item2")

-- Event Preiod
Use("i3UIStaticText_Title_Period")
Use("i3UIStaticText_Period")

-- Event Mission
Use("i3UIStaticText_Title_Mission")
Use("i3UIStaticText_Mission")

-- Attendance Check Button
Use("Btn_Attendance_Check")

-- Stamp
Use("i3UIButtonImageSet_Stamp")


-------- Recive Item Btn Click ----------
Btn_Attendance_Check:enableUIEvent(UI_EVT_CLICKED)
function Btn_Attendance_Check:OnClicked()
	CheckStamp()
end
----------------------------------------

---------------------------------------
--[BLOCK_START:UIRe\Script\PBRe_PopUp_DayCheck_01.lua]

class "AttendanceCheck" (eventHandler)

function AttendanceCheck:__init()
	i3UIStaticText:setTextMB(GAME_STRING("STR_TBL_UI_ATTENDANCE_CHECK_EVENT"))
	i3UIStaticText_Title_Period:setTextMB( GAME_STRING("STR_TBL_UI_ATTENDANCE_PERIOD") )
	i3UIStaticText_Title_Mission:setTextMB( GAME_STRING("STR_TBL_UI_ATTENDANCE_MISSION") )
	self:SetButtonText(false)
end

function AttendanceCheck:OnEvent(evt,...)
end

function AttendanceCheck:OnUpdate(tm)
end

function AttendanceCheck:SetEventData(title, period, mission)
	i3UIStaticText_Title:setText(title)
	i3UIStaticText_Period:setText(period)
	i3UIStaticText_Mission:setText(mission)

	i3UIButtonImageSet_Stamp:setEnable(false)
end

function AttendanceCheck:SetItemView(itemCount, itemName1, itemName2)

	local ItemPosX, ItemPosY = i3UIFrameWnd_Item2:getPosition()
	local ItemWidth = i3UIFrameWnd_Item1:getSize()
	local TempX;

	if itemCount == 1 then
		TempX = ItemPosX - (ItemWidth / 2)
		i3UIFrameWnd_Item2:setEnable(false)
		i3UIFrameWnd_Item1:setPosition(TempX, ItemPosY)
		i3UIStaticText_Item1:setText(itemName1)
	else
		TempX = ItemPosX - ItemWidth;
		i3UIFrameWnd_Item1:setEnable(true)
		i3UIFrameWnd_Item2:setEnable(true)
		i3UIFrameWnd_Item1:setPosition(TempX, ItemPosY)
		i3UIStaticText_Item1:setText(itemName1)
		i3UIStaticText_Item2:setText(itemName2)
	end
end

function AttendanceCheck:SetButtonText(bComplete)
	if bComplete == true then
		Btn_Attendance_Check:setTextMB( GAME_STRING("STBL_IDX_BUTTON_CLOSE") )
	else
		Btn_Attendance_Check:setTextMB( GAME_STRING("STR_TBL_UI_ATTENDANCE_CHECK") )
	end
end

function AttendanceCheck:SetBtnEnable(bEnable)
	Btn_Attendance_Check:setEnable(bEnable)
end

PBRe_PopUp_DayCheck_01 = AttendanceCheck()
--[BLOCK_END:UIRe\Script\PBRe_PopUp_DayCheck_01.lua]

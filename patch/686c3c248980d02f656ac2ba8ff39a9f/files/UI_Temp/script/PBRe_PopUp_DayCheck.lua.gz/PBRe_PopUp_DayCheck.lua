--require ���� ����
require "Script.uiLua.uiUtil"

Use("i3UIStaticText")

-- Title Label 
Use("i3UIStaticText_Title")

-- Item1 Control
Use("i3UIFrameWnd_Item1")
Use("i3UIRadio_Item1")
Use("i3UIImageBox_Item1")
Use("i3UIButtonImageSet_Item1")
Use("i3UIStaticText_Item1")

-- Item2 Control
Use("i3UIFrameWnd_Item2")
Use("i3UIRadio_Item2")
Use("i3UIImageBox_Item2")
Use("i3UIButtonImageSet_Item2")
Use("i3UIStaticText_Item2")

-- Recive Button
Use("Btn_Attendance_Check")

-------- Recive Item Btn Click ----------
Btn_Attendance_Check:enableUIEvent(UI_EVT_CLICKED)
function Btn_Attendance_Check:OnClicked()
	ReceiveItem()
end
----------------------------------------

---------------------------------------
--[BLOCK_START:UIRe\Script\PBRe_PopUp_DayCheck.lua]

class "VisitEvent" (eventHandler)

function VisitEvent:__init()
	i3UIStaticText:setTextMB(GAME_STRING("STR_TBL_UI_ATTENDANCE_CHECK_EVENT"))
	i3UIStaticText_Title:setText("")
	
	i3UIStaticText_Item1:setText("")
	i3UIRadio_Item1:setText("")
	
	i3UIStaticText_Item2:setText("")
	i3UIRadio_Item2:setText("")
	
	Btn_Attendance_Check:setTextMB( GAME_STRING("STR_UI_RECEIPT") )
end

function VisitEvent:OnEvent(evt,...)
end

function VisitEvent:OnUpdate(tm)
end

function VisitEvent:SetEventData(title, itemCnt, itemName1 , itemName2)
	i3UIStaticText_Title:setText(title)
	
	if itemCnt == 1 then
		i3UIFrameWnd_Item2:setEnable(false)
		local ItemPosX, ItemPosY = i3UIFrameWnd_Item1:getPosition()
		local ItemWidth = i3UIFrameWnd_Item1:getSize()
		local TempX = (ItemPosX + ItemWidth) / 2
		i3UIFrameWnd_Item1:setPosition(TempX, ItemPosY)
		
		i3UIRadio_Item1:setEnable(false)
		i3UIRadio_Item2:setEnable(false)
		
		i3UIStaticText_Item1:setText(itemName1)		
	else 
		i3UIRadio_Item1:setEnable(true)
		i3UIStaticText_Item1:setText(itemName1)		
	
		i3UIRadio_Item2:setEnable(true)
		i3UIStaticText_Item2:setText(itemName2)		
	end	
end

function VisitEvent:GetRadioIndex()
	if i3UIRadio_Item1:isChecked() == true then
		return 0
	elseif i3UIRadio_Item2:isChecked() == true then
		return 1
	end
	
	return -1
end


PBRe_PopUp_DayCheck = VisitEvent()
--[BLOCK_END:UIRe\Script\PBRe_PopUp_DayCheck.lua]
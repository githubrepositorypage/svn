require "Script.uiLuaString.pbString"
require "Script.uiLua.uiUtil"


Use("i3UIStaticText_Subject") -- subject
Use("i3UIStaticText_Nick") -- nick
Use("i3UIStaticText_AppNick") -- applicant
Use("i3UIStaticText_Whos") -- who's
Use("i3UIStaticText_Reason") -- reason
Use("i3UIStaticText_AgreeKey") -- agree key


Use("i3UIStaticText_RTSubject")
Use("i3UIStaticText_RTNumber")
Use("i3UIStaticText_RTSec")
-- remain time

Use("i3UIStaticText_DisagreeKey") -- reverse

Use("i3UIStaticText_NumAgree")
Use("i3UIStaticText_NumDisagree")


---------------------------------------
--[BLOCK_START:UIRe\Script\PointBlankRe_ForceExitVote.lua]


class "vote" (eventHandler)

function vote:__init()
	i3UIStaticText_Subject:setText(STR_HUD_FORCIBLYREMOVE_SUBJECT)
	i3UIStaticText_Whos:setText(STR_HUD_FORCIBLYREMOVE_WHOS)
	i3UIStaticText_RTSubject:setText( STR_HUD_FORCIBLYREMOVE_REMAIN_TIME_SUBJECT )
	i3UIStaticText_RTSec:setText( STR_HUD_FORCIBLYREMOVE_REMAIN_TIME_SECOND )
	self:SetVoted( false)
end

function vote:OnEvent(evt,...)
end

function vote:OnUpdate(tm)
end

function vote:GetVoteTime()
	return 20
end

function vote:SetTime(remain_time)
	local str = string.format("%d", remain_time)
	i3UIStaticText_RTNumber:setText(str)
end

function vote:SetInfo(app_nick, cand_nick, reason)
	i3UIStaticText_AppNick:setText(app_nick)
	i3UIStaticText_Nick:setText(cand_nick)
	
	if reason == 0 then
		i3UIStaticText_Reason:setText(STR_HUD_FORCIBLYREMOVE_REASON_NOMANNER)
	elseif reason == 1 then
		i3UIStaticText_Reason:setText(STR_HUD_FORCIBLYREMOVE_REASON_ILLEGALPROGRAM)
	elseif reason == 2 then
		i3UIStaticText_Reason:setText(STR_HUD_FORCIBLYREMOVE_REASON_ABUSE)
	else
		i3UIStaticText_Reason:setText(STR_HUD_FORCIBLYREMOVE_REASON_ETC)
	end

end

function vote:UpdateVoteCount(strAgree, strDisagree)
	i3UIStaticText_NumAgree:setText(strAgree)
	i3UIStaticText_NumDisagree:setText(strDisagree)
end

function vote:SetVoted( bVal)
	if bVal == false then
		i3UIStaticText_AgreeKey:setText(STR_HUD_FORCIBLYREMOVE_KEY_AGREE)
		i3UIStaticText_DisagreeKey:setText(STR_HUD_FORCIBLYREMOVE_KEY_REVERSE)
	else
		i3UIStaticText_AgreeKey:setText(STR_HUD_FORCIBLYREMOVE_AGREE)
		i3UIStaticText_DisagreeKey:setText(STR_HUD_FORCIBLYREMOVE_REVERSE)
	end
end

PBRe_ForceExitVote = vote()

--[BLOCK_END:UIRe\Script\PointBlankRe_ForceExitVote.lua]



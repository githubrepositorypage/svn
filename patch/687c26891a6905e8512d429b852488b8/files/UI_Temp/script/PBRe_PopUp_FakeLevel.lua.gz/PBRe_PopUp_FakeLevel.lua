--require 제거 버전
require "Script.uiLua.uiUtil"

Use("Title_PopupName")
Use("Title_ItemName")
Use("ItemName")
Use("i3UIButtonConfirm")
Use("i3UIButtonCancel")
Use("CurrentRankMark")
Use("SelectRankMark")
Use("UseItemImage")
Use("ItemExplanation")
Use("Title_ItemExplanation")

Use("CurrentRankName")
Use("SelectedRankName")

g_RankCtrlList = {}

for n = 0, 50 do
	local Rank = "Rank" .. ( n )
	Use( Rank )
	
	local RankCtrl = _G[ Rank ]
	table.insert( g_RankCtrlList, RankCtrl )
	
	RankCtrl:enableUIEvent( UI_EVT_CLICKED )
	RankCtrl.OnClicked = function( self, ... )
		SelectRank(n)
	end
	
end

i3UIButtonConfirm:enableUIEvent(UI_EVT_CLICKED)
function i3UIButtonConfirm:OnClicked()
	Confirm()
end

i3UIButtonCancel:enableUIEvent(UI_EVT_CLICKED)
function i3UIButtonCancel:OnClicked()
	ClosePopup()
end

---------------------------------------
--[BLOCK_START:UIRe\Script\PBRe_PopUp_FakeLevel.lua]

class 'FakeLevel' (eventHandler)

function FakeLevel:__init()
	Title_PopupName:setTextMB(GAME_STRING("STR_POPUP_CAPTION_USE_ITEM"))
	Title_ItemName:setTextMB(GAME_STRING("STR_POPUP_USE_ITEM"))
	Title_ItemExplanation:setTextMB(GAME_STRING("STR_POPUP_ITEM_ATTRIBUTE"))
	i3UIButtonConfirm:setTextMB(GAME_STRING("STR_POPUP_OK"))
	i3UIButtonCancel:setTextMB(GAME_STRING("STR_POPUP_CANCEL"))
	
	-- 아이템 설명
	-- STR_POPUP_CURRENT_RANK
	-- STR_POPUP_DISGUISE_RANK
	
	UseItemImage:setShape(11)
	
	for n, ctrlName in ipairs(g_RankCtrlList) do
		ctrlName:setShape(n - 1)
	end
end

function FakeLevel:OnEvent(evt,...)
end

function FakeLevel:OnUpdate(deltaSeconds)
end

function FakeLevel:SetItemInfo(itemname, description)
	ItemName:setText(itemname)
	ItemExplanation:setText(description)
end

function FakeLevel:InitRankState(CurRankName, xPos, yPos, DefaultRankName)
	CurrentRankName:setText(CurRankName)
	CurrentRankMark:setPosition(xPos, yPos)
	SelectedRankName:setText(DefaultRankName)
end

function FakeLevel:SetSelectedRank(name, xPos, yPos)

	SelectRankMark:setEnable(true)
	SelectedRankName:setText(name)
	SelectRankMark:setPosition(xPos, yPos)
end

function FakeLevel:AllRankVisible()
	for n, ctrlName in ipairs(g_RankCtrlList) do
		ctrlName:setEnable(false)
	end
	
	SelectRankMark:setEnable(false)
end

function FakeLevel:AbleToSelectRank(beginIdx, endIdx)

	for n, ctrlName in ipairs(g_RankCtrlList) do
		if n > (beginIdx) and n < (endIdx + 2) then
			ctrlName:setEnable(true)
		else
			ctrlName:setEnable(false)
		end
	end
end

PBRe_PopUp_FakeLevel = FakeLevel()---------------------------------------


--[BLOCK_END:UIRe\Script\PBRe_PopUp_FakeLevel.lua]
---------------------------------------
--[BLOCK_START:script\pbre_popup_fakelevel.lua]

--[BLOCK_END:script\pbre_popup_fakelevel.lua]

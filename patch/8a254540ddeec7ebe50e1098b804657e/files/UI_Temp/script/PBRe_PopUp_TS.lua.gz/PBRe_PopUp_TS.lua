--require 제거 버전
require "Script.uiLua.uiUtil"

Use("i3UIStaticText3")	--제목
Use("i3UIStaticText")	--이름
Use("i3UIStaticText19")	--플레이 시간

Use("i3UIImageBox4")	--왼쪽 아이템
Use("i3UIButtonImageSet")	--왼쪽 아이템 이미지
Use("i3UIStaticText4")	--왼쪽 아이템 이미지

Use("i3UIImageBox0")	--오른쪽 아이템
Use("i3UIButtonImageSet0")	--왼쪽 아이템 이미지
Use("i3UIStaticText18")	--왼쪽 아이템 이미지

Use("btn1")	--아이템 받기 버튼

tlb_item_name = {i3UIStaticText4, i3UIStaticText18}

---------------------------------------
--[BLOCK_START:UIRe\Script\PBRe_PopUp_TS.lua]


i3UIImageBox4:enableUIEvent(UI_EVT_CLICKED)
function i3UIImageBox4:OnClicked()
	SelectItem(0)
end
i3UIButtonImageSet:enableUIEvent(UI_EVT_CLICKED)
function i3UIButtonImageSet:OnClicked()
	SelectItem(0)
end


i3UIImageBox0:enableUIEvent(UI_EVT_CLICKED)
function i3UIImageBox0:OnClicked()
	SelectItem(1)
end
i3UIButtonImageSet0:enableUIEvent(UI_EVT_CLICKED)
function i3UIButtonImageSet0:OnClicked()
	SelectItem(1)
end


btn1:enableUIEvent(UI_EVT_CLICKED)
function btn1:OnClicked()
	Confirm()
end


class "TsPopUp" (eventHandler)

function TsPopUp:__init()
	btn1:setTextMB(GAME_STRING("STBL_IDX_BUTTON_OK"))
end

function TsPopUp:OnEvent(evt,...)
end

function TsPopUp:OnUpdate(tm)
end

-----------------------------------------
function TsPopUp:SetTitle(str)
	i3UIStaticText3:setText(str)
end
function TsPopUp:SetName(str)
	i3UIStaticText:setText(str)
end
function TsPopUp:SetPlayTime(str)
	i3UIStaticText19:setText(str)
end

function TsPopUp:SetItemName(inx, str)
	local tbl_idx = inx+ 1
	tlb_item_name[ tbl_idx ]:setText(str)
end

PBRe_PopUp_TS = TsPopUp()

--[BLOCK_END:UIRe\Script\PBRe_PopUp_TS.lua]
---------------------------------------



